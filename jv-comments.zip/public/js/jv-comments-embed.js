	(function () {
		var d = document, s = d.createElement('script');
		s.src = 'https://widget.jointcomments.com/e/embed.prod.js';
		if (/MSIE|Trident/.test(window.navigator.userAgent)) {
				s.src = 'https://widget.jointcomments.com/e/embed.prodIE.js';
		}
		(d.head || d.body).appendChild(s);
	})();
