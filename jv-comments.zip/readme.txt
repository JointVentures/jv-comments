=== Joint Comments Embedder ===
Contributors: jointventures
Tags: commenting, comment, comment widget, disqus alternative, wordpress comments alternative, comment moderation, review plugin
Requires at least: 4.0
Tested up to: 5.2
Stable tag: 4.1.2
License: GPLv2 or later

Get more engagement with our easy to use commenting system. The setup takes just a few clicks.

== Description ==

Joint Comments - Embeddable Comment Widget
Your content deserves much more comments.

Get more engagement with our easy to use commenting system. The setup takes just a few clicks.

Platform Features:
* Manage multiple websites in one dashboard
* Embed anywhere (websites, static pages, ecommerce)
* Invite your team members as moderators
* Define upvote & comment limits
* Customize the widget colors and widget position
* See stats of your community
* See top commenters & top comments
* Ban users permanently or temporarily
* Notifications for commenters

== Installation ==

Upload the Joint Comments Embedder plugin to your blog, Login or Register for a new account, select your comment moderation option, you're done! 

== Changelog ==

= 1.0.0 =
*Release Date - 16 Aug 2019*

* First Release



